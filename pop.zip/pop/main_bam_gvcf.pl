#!/usr/bin/perl -w
use strict;
use warnings;
# firstly, you need check the chromosome id of reference genome: grep ">" $ref

# step 0
print "step 0: predeal\n";
####
my $main = `pwd`; chomp($main);
my $picard = "/home/yjq/biosoftwares/population/picard/build/libs/picard.jar";
my $gatk_jar = "/home/yjq/anaconda3/envs/gatk3.8/opt/gatk-3.8/GenomeAnalysisTK.jar";
my $gatk4="/data-storage/Public/yjq/bats_proj/pop_update/softwear/gatk/gatk-4.2.3.0/gatk";
my $qualimap = "/home/yjq/anaconda3/bin/qualimap";
my $beagle = "/data-storage/Public/yjq/bats_proj/pop_update/softwear/beagle/beagle.27Jan18.7e1.jar";
my $smartpca = "/home/yjq/anaconda3/bin/smartpca";
my $admixture = "/home/yjq/anaconda3/bin/admixture";

my $sp = "FCA";
my $sample_abbr = "_sra";
my $genome_dir = "$main/0.ref";
my $ori_genome = "$sp.genome.fasta"; # 修改对应基因组
my $ref_index = "$sp.genome.fasta.fai"; # 修改对应基因组
my $ref = $ori_genome; #$ref =~ s/fas$/fasta/;
my $foldername="/home/yjq/databases/up_fni/0.fqs/pri_lin";# change into your own dir
##
my $sra_ids = "$main/configure/sra.txt";
my $match_list = "$main/configure/sra.match.list";
####
my @chrs = ("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
my $auto_chr = "18";
my $sex = "19";
#my $ind_num = "11";
####

print "0.predeal\n";
my $predeal = "0.predeal"; unless(-e $predeal){system("mkdir -p $predeal");}
unless(-e "0.predeal.ok"){
	chdir $predeal;
	print "0.1 predeal ref. genome\n\n";
	unless(-e "0.1.ref_filter.ok"){ # change this part based on your own genome ids
		open(ORI, "$main/$genome_dir/$ori_genome") or die "$!";
		my $id; my %hash;
		while(my $line = <ORI>){
			chomp($line);
			if($line =~ m/^>(\S+)/){
				$id = $1; print "ids: $id\n";
				$hash{$id} = "";
			}else{
				$hash{$id} .= $line."\n";
			}
		}close ORI;

		open(CHR, ">$main/$genome_dir/$ref") or die "$!";
		my %hash_chr; my $chr_X;
		foreach my $each (sort (keys %hash)){
			next if $each =~ m/^unchr_\d+/;
			print "chromosomes: $each\n";
			print CHR ">$each\n$hash{$each}";
		}close CHR;
		
		open(OUT, ">0.1.ref_filter.ok") or die $!; close OUT;
	}

	print "0.2.sra\n";
	my $sra_download = "0.download_sra"; unless(-e $sra_download){system("mkdir -p $sra_download");}
	unless(-e "0.2.sra.ok"){
		my $sra_dir = "0.download_sra";
		print "0.2.1.download_sra.\n";
		unless(-e "0.2.1.download_sra.ok"){
			system("prefetch -t ascp --option-file $sra_ids -X 100G -O ./$sra_download") == 0 or die $!;
			open(OUT, ">0.2.1.download_sra.ok") or die $!; close OUT;
		}

		open(IN, $match_list) or die $!;
		my %hash;
		while(my $line = <IN>){
			chomp $line;
			my @arr = split(/\s+/, $line);
			$hash{$arr[0]} = $arr[1];
			print "sra_list: $arr[0]\t$hash{$arr[0]}\n";
		}close IN;

		print "0.2.2.fastq-dump\n";
		unless(-e "0.2.2.fastq-dump.ok"){
			opendir(FD, $sra_dir); my @fdirs = grep(/^[S|E|D]RR/, readdir(FD)); close FD; my @sort_fdirs = sort @fdirs;
			chdir $sra_dir;
			print "working dir: $sra_dir\n";
			open(PA_DUMP, ">para_fastq_dump.txt") or die $!;	
			foreach my $fir (@sort_fdirs){
				opendir(SD, "$fir"); my @sdirs = grep(/sra$/, readdir(SD)); close SD; my @sort_sdirs = sort @sdirs; 
				print "working dir: $fir\n";
				foreach my $sec (@sort_sdirs){
					print "sra_file: $sec\n";
					my $def_seq = '@$sn[_$rn]/$ri';
					my $out = $hash{$fir}."_sra"; 
					unless(-e $out){system("mkdir -p $out") == 0 or die $!;}
					print PA_DUMP "fastq-dump --defline-seq '$def_seq' --split-3 ./$fir/$sec -O $out\n";
				}
			}
			close PA_DUMP;
			print "working dir: $sra_dir\n";
			system("ParaFly -c para_fastq_dump.txt -CPU 24") == 0 or die $!;
			chdir ".."; 
			open(OUT, ">0.2.2.fastq-dump.ok") or die $!; close OUT;
		}
		open(OUT, ">0.2.sra.ok") or die $!; close OUT;
	}
	chdir "..";
	open(OUT, ">0.predeal.ok") or die $!; close OUT;
}


# step 1
print "step 1: map\n";
my $map = "1.map"; unless(-e "$map"){system("mkdir -p $map");}
my $tmp = "00.temp"; unless(-e "$tmp"){system("mkdir -p $tmp");}
unless(-e "1.map.ok"){
	chdir "1.map";
	#my $foldername="$main/$predeal/0.download_sra";# change into your own dir
	#my $foldername="/home/yjq/databases/up_fni/pri_lin";# change into your own dir
	opendir(FD, $foldername) or die $!; my @sp_sra_dir = grep(/$sample_abbr/, readdir(FD)); close FD;
	print "1.1.index\n";
	unless(-e "1.1.index.ok"){
		#system("ln -s $genome_dir/$ref") == 0 or die $!;
		system("bwa index -a bwtsw $genome_dir/$ref") == 0 or die $!; # for bam
		system("samtools faidx $genome_dir/$ref") == 0 or die $!; # for gvcf
		my $dict = $ref; $dict =~ s/fasta$/dict/;
		unless(-e "$genome_dir/$dict"){system("java -Xmx100g -jar $picard CreateSequenceDictionary R=$genome_dir/$ref O=$genome_dir/$dict") == 0 or die $!;} # for gvcf
		open(OUT, ">1.1.index.ok") or die $!; close OUT;
	}
	
	print "1.2.samtools\n";
	unless(-e "1.2.samtools.ok"){
		my $pa_bam = "para_bamtools.txt";
		open(PA_BAM, ">$pa_bam") or die $!;	
		foreach my $sp_sra (sort @sp_sra_dir){
			print "$sp_sra\n";
			my $match = "1\.fastq\.gz";
			#if($sp_sra =~ m/^FSS/){$match = "\.fastq"; print "$match\n";}
			opendir(SD, "$foldername/$sp_sra") or die $!; my @sras_1 = grep(/$match$/, readdir(SD)); close SD;
			foreach my $sra1 (sort @sras_1){
				my $lib = $sra1; 
				my $sra2 = $sra1; 
				if($sp_sra =~ m/^FSS/){
					$lib =~ s/\.fastq$//;
				}
				$lib =~ s/_1.fastq\.gz//;
				$sra2 =~ s/_1\.fastq.gz$/_2.fastq.gz/;
				my $outname = $sp_sra; $outname =~ s/_sra$//;
				print "$lib\t$sra1\t$sra2\n";
				
				my $sai=$outname.'.sai';
				my $sam=$outname.'.sam';
				my $bam=$outname.'.bam';
				my $sort=$bam;  $sort=~s/\.bam/\_sort.bam/;
				my $rmdup=$sort;  $rmdup=~s/_sort\.bam/\_rmdup.bam/;
				
				#y $sign = "\@RG\tID:$lib\tLB:$lib\tPL:ILLUMINA\tSM:$lib";
				#my $sign = "\@RG\tID:foo\tLB:library1\tPL:ILLUMINA\tSM:bar";
				my $cmd1 = "bwa mem -t 64 -M -R \"\@RG\\tID:$lib\\tLB:$lib\\tPL:ILLUMINA\\tSM:$lib\" $genome_dir/$ref $foldername/$sp_sra/$sra1 $foldername/$sp_sra/$sra2 | samtools view -bS - > $bam";
				#if($sp_sra =~ m/FSS*_sra$/){$cmd1 = "bwa mem -t 64 -M -R \"\@RG\\tID:$lib\\tLB:$lib\\tPL:ILLUMINA\\tSM:$lib\" $genome_dir/$ref $foldername/$sp_sra/$sra1 | samtools view -bS - > $bam";}
				my $cmd2 = "java -Djava.io.tmpdir=$main/$tmp -Xmx100g -jar $picard SortSam I=$main/$map/$bam O=./$sort SORT_ORDER=coordinate && rm $bam";
				my $cmd3 = "java -Djava.io.tmpdir=$main/$tmp -Xmx100g -jar $picard MarkDuplicates I=./$sort O=./$rmdup M=./$sam.marked_dup_metrics.txt REMOVE_DUPLICATES=true CREATE_INDEX=true && rm $sort";
				#my $cmd8 = "samtools index $rmdup";
				print PA_BAM "$cmd1 && $cmd2 && $cmd3\n";
			}
		}
		close PA_BAM;
		system("ParaFly -c $pa_bam -CPU 64") == 0 or die $!;
		open(OUT, ">1.2.samtools.ok") or die $!; close OUT;
	}
	
	print "1.3.bamqc\n";
	my $bamqc_dir = "bamqc"; unless(-e "$bamqc_dir"){system("mkdir -p $bamqc_dir");}
	unless(-e "1.3.bamqc.ok"){
		chdir $bamqc_dir;
		
		my $pa_bamqc = "../para_bamqc.txt"; # donot put in the directory of bamqc
		open(PA_BAMQ, ">$pa_bamqc") or die $!;	
		opendir(WKD, "..") or die $!; my @bams = grep(/^\D\D\D\d+_rmdup\.bam$/, readdir(WKD)); close WKD;
		foreach my $bam_rmd (sort @bams){
			my $out_bamqc = $bam_rmd; $out_bamqc =~ s/_rmdup\.bam$/_bqc/; unless(-e "$out_bamqc"){system("mkdir -p $out_bamqc");}
			print PA_BAMQ "$qualimap bamqc -bam ../$bam_rmd -outdir $out_bamqc -outformat HTML --java-mem-size=20G\n";
		}
		close PA_BAMQ;
		system("ParaFly -c $pa_bamqc -CPU 12") == 0 or die $!;
		
		chdir "..";
		open(OUT, ">1.3.bamqc.ok") or die $!; close OUT;
	}
	system("python $main/scripts/fetchBAMQCDepth.py ./bamqc > result") == 0 or die $!; # depth calculate
	
	chdir "..";
	open(OUT, ">1.map.ok") or die $!; close OUT;
}


# step 2
print "step 2: bam2vcf\n";
my $gvcf = "2.gvcf"; unless(-e "$gvcf"){system("mkdir -p $gvcf");}
opendir(WKD, "$map") or die $!; my @bams = grep(/^\D\D\D\d+_rmdup\.bam$/, readdir(WKD)); close WKD;
unless(-e "2.bam2vcf.ok"){
	chdir $gvcf;
	unless(-e "2.1.produceShell_for_gvcf.ok"){
		unless(-e "$main/$gvcf/00.gvcf_tmp"){system("mkdir -p $main/$gvcf/00.gvcf_tmp") == 0 or die $!;}
		#open(NLS, "./scripts/list") die $!;
		#my %ha1;
		#while(my $line = <NLS>){chomp $line;$ha1{$line} = 1;}close NLS;
		#my @chrs = ("A1","A2","A3","B1","B2","B3","B4","C1","C2","D1","D2","D3","D4","E1","E2","E3","F1","F2","X");
		#my @chrs = ("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
		my $pa_gvcf = "para_run.gvcf.txt";
		open(PA, ">$pa_gvcf") or die $!;
		#my $gatk_jar = "/home/Ting/anaconda3/opt/gatk-3.8/GenomeAnalysisTK.jar";
		foreach my $bam (sort @bams){
			print "##$bam\n";
			foreach my $chr (sort @chrs){
				my $out = $bam; $out =~ s/_rmdup\.bam$//; $out = $chr."_".$out.".g.vcf.gz";
				#my $cmd = "java -Djava.io.tmpdir=$main/$gvcf/00.gvcf_tmp -Xmx40g -jar $gatk_jar -T HaplotypeCaller -R $genome_dir/$ref -ERC GVCF -variant_index_type LINEAR -variant_index_parameter 128000 -nct 8 -L $chr -I $main/$map/$bam -o $main/$gvcf/$out";
				my $cmd = "cd $main/$map && java -Djava.io.tmpdir=$main/$gvcf/00.gvcf_tmp -Xmx40g -jar $gatk_jar -T HaplotypeCaller -R $genome_dir/$ref -ERC GVCF -variant_index_type LINEAR -variant_index_parameter 128000 -nct 8 -L $chr -I $bam -o $main/$gvcf/$out && cd $main/$gvcf";
				print PA "$cmd\n";
			}
		}close PA;
		system("ParaFly -c $pa_gvcf -CPU 48") == 0 or die $!; # 19*n chromosome
		#system("python ./scripts/01.produceShell_for_gvcf.py ./scripts/list") == 0 or die $!;
		open(OUT, ">2.1.produceShell_for_gvcf.ok") or die $!; close OUT;
	}	
	chdir "..";
	open(OUT, ">2.bam2vcf.ok") or die $!; close OUT;	
}

#=pod
# step 3
print "step 3: merge\n";
my $merge = "3.merge"; unless(-e "$merge"){system("mkdir -p $merge");}
opendir(WKD, "$gvcf") or die $!; my @gvcfs = grep(/\.g\.vcf\.gz$/, readdir(WKD)); close WKD;
unless(-e "3.merge.ok"){
	chdir $merge;
	unless(-e "$main/$merge/00.merge_tmp"){system("mkdir -p $main/$merge/00.merge_tmp") == 0 or die $!;}
	#my @chrs = ("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
	my $pa_merge = "para_run.merge.txt";
	open(PA, ">$pa_merge") or die $!;
	foreach my $chr (sort @chrs){
		print "$chr\n";

		my $vcf_sample = $chr.".sample.list"; # 文件必须是"*.list"
		open(VCFS, ">$vcf_sample") or die $!;
		foreach my $vcf (sort @gvcfs){
			my $match = $vcf; $match =~ s/_.*\.g\.vcf\.gz$//;
			if($match eq "$chr"){
				print VCFS "$main/$gvcf/$vcf\n";
			}
		}close VCFS;
		
		my $out = $chr.".merge.g.vcf.gz";
		my $cmd = "java -Djava.io.tmpdir=$main/$merge/00.gvcf_tmp -Xmx40g -jar $gatk_jar -T CombineGVCFs -R $genome_dir/$ref --variant $vcf_sample -o $out";
		print PA "$cmd\n";
	}close PA;
	system("ParaFly -c $pa_merge -CPU 19") == 0 or die $!; # 19*n chromosome
	
	chdir "..";
	open(OUT, ">3.merge.ok") or die $!; close OUT;
}


# step 4
print "step 4: gtype\n";
my $gtype = "4.gtype"; unless(-e "$gtype"){system("mkdir -p $gtype");}
unless(-e "4.gtype.ok"){
	chdir $gtype;
	unless(-e "$main/$gtype/00.gtype_tmp"){system("mkdir -p $main/$gtype/00.gtype_tmp") == 0 or die $!;}
	#my @chrs = ("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
	my $pa_gtype = "para_run.gtype.txt";
	open(PA, ">$pa_gtype") or die $!;
	foreach my $chr (sort @chrs){
		print "$chr\n";
		my $out = $chr.".vcf.gz";
		my $cmd = "java -Djava.io.tmpdir=$main/$gtype/00.gtype_tmp -Xmx40g -jar $gatk_jar -T GenotypeGVCFs -R $genome_dir/$ref --variant $main/$merge/$chr.merge.g.vcf.gz -o $out --disable_auto_index_creation_and_locking_when_reading_rods --includeNonVariantSites -stand_call_conf 10";
		print PA "$cmd\n";
	}close PA;
	system("ParaFly -c $pa_gtype -CPU 19") == 0 or die $!; # 19*n chromosome
	
	chdir "..";
	open(OUT, ">4.gtype.ok") or die $!; close OUT;
}


# step 5
print "step 5: filter\n"; # the cpu limits
my $filter = "5.filter"; unless(-e "$filter"){system("mkdir -p $filter");}
#opendir(WKD, "$gtype") or die $!; my @gtypes = grep(/\.vcf\.gz$/, readdir(WKD)); close WKD;
unless(-e "5.filter.ok"){
	chdir $filter;
	unless(-e "$main/$filter/00.merge_tmp"){system("mkdir -p $main/$filter/00.filter_tmp") == 0 or die $!;}
	my @chrs = ("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
	my $pa_filter = "para_run.filter.txt";
	open(PA, ">$pa_filter") or die $!;
	foreach my $chr (sort @chrs){
		print "$chr\n";
		my $out = $chr.".raw.SNP.vcf.gz";
		my $cmd1 = "java -Djava.io.tmpdir=$main/$merge/00.gvcf_tmp -Xmx10g -jar $gatk_jar -T SelectVariants -R $genome_dir/$ref -V $main/$gtype/$chr.vcf.gz -nt 1 -selectType SNP --excludeNonVariants --removeUnusedAlternates -restrictAllelesTo BIALLELIC --logging_level ERROR  -o $out"; # nt 需要改为1，否则报错
		
		my $eve_dep = 0; 
#		opendir(BAMQC, "$main/$map/bamqc") or die $!; my @bamqcs = grep(/\_bqc$/,readdir(BAMQC)); close BAMQC;
#		foreach my $bamqc (@bamqcs){
#			open(IN, "$main/$map/bamqc/$bamqc") or die $!;
#			while(my $line = <IN>){
#				chomp $line;
#				if($line =~ m/^\s+mean coverageData = (\d+)\.\d+X$/){
#					$eve_dep += $eve_dep;
#				}
#			}close IN;
#		}
		open(IN, "$main/$map/result") or die $!;
		my $plus;
		while(my $line = <IN>){
			chomp $line;
			my @arr = split(/\s+/, $line);
			next if $arr[0] eq "samplt";
			if($arr[4] =~ m/(\d+)\.\d+X$/){
				$plus = $1;
				$eve_dep += $plus;
			}
		}close IN;
		my $min_filterdep = $eve_dep/3; my $max_filterdep = $eve_dep*3;
		print "depth: $min_filterdep\t$eve_dep\t$max_filterdep\n";
		#my $filt_exp = "DP < 105 || DP > 945 || QD < 2.0 || FS > 60.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0 || SOR > 3.0"; # eve_dep = 315
		my $filt_exp = "DP < $min_filterdep || DP > $max_filterdep || QD < 2.0 || FS > 60.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0 || SOR > 3.0";
		#my $cmd2 = "java -Djava.io.tmpdir=$main/$merge/00.gvcf_tmp -Xmx40g -jar $gatk_jar -T VariantFiltration -R $genome_dir/$ref -V $chr.raw.SNP.vcf.gz --logging_level ERROR --filterExpression $filt_exp --filterName filtered --clusterSize 3 --clusterWindowSize 10 -o $chr.filter.SNP.vcf.gz";
		my $cmd2 = "java -Djava.io.tmpdir=$main/$merge/00.gvcf_tmp -Xmx40g -jar $gatk_jar -T VariantFiltration -R $genome_dir/$ref -V $chr.raw.SNP.vcf.gz --logging_level ERROR --filterExpression \"DP < $min_filterdep || DP > $max_filterdep || QD < 2.0 || FS > 60.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0 || SOR > 3.0\" --filterName filtered --clusterSize 3 --clusterWindowSize 10 -o $chr.filter.SNP.vcf.gz";
		my $cmd3 = "$gatk4 --java-options -Xmx40G SelectVariants -R $genome_dir/$ref --select-type-to-include SNP -restrict-alleles-to BIALLELIC --remove-unused-alternates --exclude-non-variants -exclude-filtered -V $chr.filter.SNP.vcf.gz -O $chr.clean.SNP.vcf.gz";
		print PA "$cmd1 && $cmd2 && $cmd3\n";
	}close PA;
	system("ParaFly -c $pa_filter -CPU 19") == 0 or die $!; # 19*n chromosome
	
	chdir "..";
	open(OUT, ">5.filter.ok") or die $!; close OUT;
}


# step 6
print "step 6: catall\n";
my $catall = "6.catall"; unless(-e "$catall"){system("mkdir -p $catall");}
opendir(DIR, "$main/$filter") or die $!; my @filters = grep(/\.clean\.SNP\.vcf\.gz$/, readdir(DIR)); close DIR; 
unless(-e "6.catall.ok"){
	chdir $catall;
	unless(-e "$main/$catall/00.catall_tmp"){system("mkdir -p $main/$catall/00.catall_tmp") == 0 or die $!;}
	open(SAMX, ">sample.list") or die $!;
	open(SAM, ">sample_nox.list") or die $!;
	foreach my $one (sort @filters){
		my $chr = $one; $chr =~ s/\.clean\.SNP\.vcf\.gz$//;
		print SAMX "$main/$filter/$one\n";
		next if $chr eq $sex; # remove the x chromosome
		print SAM "$main/$filter/$one\n";
	}close SAM; close SAMX;
	my $cmd1 = "java -Djava.io.tmpdir=00.catall_tmp -Xmx100g -cp $gatk_jar org.broadinstitute.gatk.tools.CatVariants -R $genome_dir/$ref --variant sample.list -out ./combined.vcf.gz -assumeSorted";
	my $cmd2 = "java -Djava.io.tmpdir=00.catall_tmp -Xmx100g -cp $gatk_jar org.broadinstitute.gatk.tools.CatVariants -R $genome_dir/$ref --variant sample_nox.list -out ./combined_nox.vcf.gz -assumeSorted";
	open(PA, ">para_catall.txt") or die $!;
	print PA "$cmd1\n";
	print PA "$cmd2\n";
	close PA;
	system("ParaFly -c para_catall.txt -CPU 2") == 0 or die $!;
	
	chdir "..";
	open(OUT, ">6.catall.ok") or die $!; close OUT;
}

=pod
# step 7
print "step 7: phase\n";
my $phase = "7.phase"; unless(-e "$phase"){system("mkdir -p $phase");}
unless(-e "7.phase.ok"){
	chdir $phase;
	unless(-e "0.phase.each.ok"){
		open(PA_PH, ">para_phase.txt") or die $!;
		foreach my $one (sort @filters){
			my $chr = $one; $chr =~ s/\.clean\.SNP\.vcf\.gz$//;
			my $cmd1 = "java -Xmx40g -Xss128m -jar $beagle chrom=$chr gtgl=$main/$filter/$chr.clean.SNP.vcf.gz out=$chr.imp nthreads=6 gprobs=true niterations=10";
			my $cmd2 = "java -Xmx40g -Xss128m -jar $beagle gt=./$chr.imp.vcf.gz out=./$chr.imp.phase gprobs=true niterations=10 nthreads=8";
			print PA_PH "$cmd1 && $cmd2\n";
		}close PA_PH;
		system("ParaFly -c para_phase.txt -CPU 19") == 0 or die $!;
		open(OUT, ">0.phase.each.ok") or die $!; close OUT;
	}
	
	unless(-e "$main/$phase/00.phase_tmp"){system("mkdir -p $main/$phase/00.phase_tmp") == 0 or die $!;}	
	opendir(DIR, "./") or die $!; my @phases = grep(/\.imp\.phase\.vcf\.gz$/, readdir(DIR)); close DIR; 
	open(SAMX, ">sex.list") or die $!;
	open(SAM, ">sample.list") or die $!;
	foreach my $one (sort @phases){
		my $chr = $one; $chr =~ s/\.imp\.phase\.vcf\.gz$//;
		if($chr eq $sex){# the x chromosome
			print SAMX "$main/$phase/$one\n";
			next;
		}
		print SAM "$main/$phase/$one\n"; # without x chromosome
	}close SAM; close SAMX;
	my $cmd3 = "java -Xmx100g -Djava.io.tmpdir=00.phase_tmp -cp $gatk_jar org.broadinstitute.gatk.tools.CatVariants -R $genome_dir/$ref -V sample.list -out allAuto_chr.phase.merge.vcf.gz -assumeSorted";
	my $cmd4 = "java -Xmx100g -Djava.io.tmpdir=00.phase_tmp -cp $gatk_jar org.broadinstitute.gatk.tools.CatVariants -R $genome_dir/$ref -V sex.list -out X_chr.phase.merge.vcf.gz -assumeSorted";
	open(PA, ">para_catphase.txt") or die $!;
	print PA "$cmd3\n";
	print PA "$cmd4\n";
	close PA;
	system("ParaFly -c para_catphase.txt -CPU 2") == 0 or die $!;
	
	chdir "..";
	open(OUT, ">7.phase.ok") or die $!; close OUT;
}

=pod
# step 8
print "step 8: analysis\n";
my $ana = "8.analysis"; unless(-e "$ana"){system("mkdir -p $ana");}
unless(-e "8.ana.ok"){
	chdir $ana;	
	print "working dir: $ana\n";
	# step 8.1
	print "step 8.1: plink\n";
	unless(-e "8.1.plink.ok"){
		unless(-e "8.1.plink"){system("mkdir -p 8.1.plink");}
		chdir "8.1.plink";
		#my $cmd1 = "vcftools --gzvcf $main/$catall/combined_nox.vcf.gz --plink --chrom-map chrID --out $sp";
		my $cmd1 = "vcftools --gzvcf $main/$catall/combined_nox.vcf.gz --plink --out $sp";
		#my $cmd2 = "plink --file $sp --chr-set $auto_chr --make-bed --out $sp";
		my $cmd2 = "plink --file $sp --make-bed --out $sp";
		system("$cmd1 && $cmd2") == 0 or die $!;
		
		chdir "..";
		open(OUT, ">8.1.plink.ok") or die $!; close OUT;
	}
	
	# step 8.2
	print "step 8.2: pca\n";
	unless(-e "8.2.pca.ok"){
		unless(-e "8.2.pca"){system("mkdir -p 8.2.pca");}
		chdir "8.2.pca";
		open(PCA_COF, ">$sp.eigensoft_smartpca.par") or die $!;
		print PCA_COF "genotypename: $main/$ana/8.1.plink/$sp.bed\n";
		print PCA_COF "snpname: $main/$ana/8.1.plink/$sp.bim\n";
		print PCA_COF "indivname: $main/$ana/8.1.plink/$sp.fam\n";
		print PCA_COF "evecoutname: $sp.evec\n";
		print PCA_COF "evaloutname: $sp.eval\n";
		print PCA_COF "numoutevec: 10\n";
		print PCA_COF "numoutlieriter: 0\n";
		print PCA_COF "numoutlierevec: 10\n";
		print PCA_COF "nsnpldregress: 0\n";
		print PCA_COF "outliersigmathresh: 6.0\n";
		print PCA_COF "outlieroutname: $sp.log\n";
		print PCA_COF "usenorm: YES\n";
		close PCA_COF;
		my $cmd = "$smartpca -p $sp.eigensoft_smartpca.par";
		system("$cmd") == 0 or die $!;
		
		chdir "..";
		open(OUT, ">8.2.pca.ok") or die $!; close OUT;
	}	
	
	# step 8.3
	print "step 8.3: nj\n";
	unless(-e "8.3.nj.ok"){
		unless(-e "8.3.nj"){system("mkdir -p 8.3.nj");}
		chdir "8.3.nj";

		my $cmd1 = "plink --bfile ../8.1.plink/$sp --chr-set $auto_chr --distance-matrix --out $sp";
		my $cmd2 = "perl $main/scripts/plink.distance.matrix.to.mega.pl $sp.mdist.id $sp.mdist $ind_num $sp";# Usage : perl $0 <mdist.id> <mdist> <individual number> <out prefix>
		system("$cmd1") == 0 or die $!;
		system("$cmd2") == 0 or die $!;
		
		chdir "..";
		open(OUT, ">8.3.nj.ok") or die $!; close OUT;
	}
	
	# step 8.4
	print "step 8.4: structure\n";
	unless(-e "8.4.structure.ok"){
		unless(-e "8.4.structure"){system("mkdir -p 8.4.structure");}
		chdir "8.4.structure";
		
		my $rounds = 4;# assume structure rounds
		open(PA, ">para_structure.txt") or die $!;
		for(my $i = 0; $i<=$rounds; $i++){
			my $cmd = "$admixture --cv ../8.1.plink/$sp.bed $i | tee log${i}.out";
			print PA "$cmd\n";
		}
		close PA;
		system("ParaFly -c para_structure.txt -CPU $rounds") == 0 or die $!;
		
		chdir "..";
		open(OUT, ">8.4.structure.ok") or die $!; close OUT;
	}
	
	# step 8.5 # mannually 
	print "step 8.5: selection\n";
	unless(-e "8.5.selection.ok"){
		unless(-e "8.5.selection"){system("mkdir -p 8.5.selection");}
		chdir "8.5.selection";
		
		chdir "..";
		open(OUT, ">8.5.selection.ok") or die $!; close OUT;
	}
	
	# step 8.6 # mannually 
	print "step 8.6: psmc\n";
	
	# step 8.8 # mannually 
	print "step 8.8: treemix\n";
	
	
	chdir "..";
	open(OUT, ">8.stat.ok") or die $!; close OUT;
}


#=pod
# step 9
print "step 9: diversity\n";
my $div = "9.diversity"; unless(-e "$div"){system("mkdir -p $div");}


# step 10
print "step 10: introgression\n";
my $intro = "9.diversity"; unless(-e "$div"){system("mkdir -p $div");}
=cut