#!/usr/bin/perl -w
use strict;
####
#stastic  SNP scenario
####
die "Usage:perl $0 <vcf|gzip vcf> <output>\n" unless @ARGV == 2;
my $input = $ARGV[0];
open (IN,($input =~ /\.gz$/)? "gzip -dc $input |" : $input) or die "gzipped vcf file required!\n";
my @header;
my $total_site = 0;
my $minor_ref = 0; #minor ref
my $minor_alt = 0; #minor alt
my $minor_ref_singleton = 0;
my $minor_alt_singleton = 0;
my %singleton;
my %snp;
my %het;
my %ref_hom;
my %missing;
my %fix;
while(<IN>){
	next if /^##/;
	chomp;
	if (/^#CHR/){
		@header = split/\t/;
	}
	else{
		my @genotype = split/\t/;
		$total_site++;
		my ($AC) = $genotype[7] =~ /AC=(\d+)/;
		my ($AF) = $genotype[7] =~ /AF=(\S+?);/;
		my ($AN) = $genotype[7] =~ /AN=(\d+)/;
		my $singleton_validate = 0;
		if ($AF >= 0.5){                                 #ref will be minor allele
			$minor_ref++;
			if ($AN - $AC == 1){
				$minor_ref_singleton++;
				foreach my $index (9..$#genotype){
					if ($genotype[$index] =~ /^0\/1|^0\|1|^1\|0/){
						$singleton_validate++;
						$singleton{$header[$index]}++;
						$snp{$header[$index]}++;
						$het{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^1\/1|^1\|1/){
						$snp{$header[$index]}++;
						$fix{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^\.\/./){
						$missing{$header[$index]}++;
					}
					else{
						die "$genotype[$index] may not come from GATK\n";
					}
				}
				die "$_ singleton validate failed $singleton_validate!\n" if $singleton_validate != 1;
			}
			elsif ($AN - $AC > 1){
				foreach my $index (9..$#genotype){
					if ($genotype[$index] =~ /^0\/1|^0\|1|^1\|0/){
						$singleton_validate++;
						$snp{$header[$index]}++;
						$het{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^1\/1|^1\|1/){
						$snp{$header[$index]}++;
						$fix{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^0\/0|^0\|0/){
						$singleton_validate += 2;
						$ref_hom{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^\.\/./){
						$missing{$header[$index]}++;
					}
					else{
						die "$genotype[$index] may not come from GATK\n";
					}
				}
				die "$_ singleton validate failed $singleton_validate!\n" if $singleton_validate == 1;		
			}
			elsif ($AN - $AC == 0){      #all sample are 1/1
				foreach my $index (9..$#genotype){
					if($genotype[$index] =~ /^1\/1|^1\|1/){
						$snp{$header[$index]}++;
						$fix{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^\.\/./){
						$missing{$header[$index]}++;
					}
					else{
						die "$_\n$genotype[$index] may not come from GATK\n";
					}
				}
			}
			else{
				die "$_ may not come from GATK\n";
			}
		}
		else{                                            #alt will be minor allele
			$minor_alt++;
			if ($AC == 1){
				$minor_ref_singleton++;
				foreach my $index (9..$#genotype){
					if ($genotype[$index] =~ /^0\/1|^0\|1|^1\|0/){
						$singleton_validate++;
						$singleton{$header[$index]}++;
						$snp{$header[$index]}++;
						$het{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^1\/1|^1\|1/){
						$singleton_validate += 2;
						$snp{$header[$index]}++;
						$fix{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^0\/0|^0\|0/){
						$ref_hom{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^\.\/./){
						$missing{$header[$index]}++;
					}
					else{
						die "$_ may not come from GATK\n";
					}
				}
				die "$_ singleton validate failed $singleton_validate!\n" if $singleton_validate != 1;
			}
                        elsif ($AC > 1){
				foreach my $index (9..$#genotype){
					if ($genotype[$index] =~ /^0\/1|^0\|1|^1\|0/){
						$singleton_validate++;
						$snp{$header[$index]}++;
						$het{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^1\/1|^1\|1/){
						$singleton_validate += 2;
						$snp{$header[$index]}++;
						$fix{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^0\/0|^0\|0/){
						$ref_hom{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^\.\/./){
						$missing{$header[$index]}++;
					}
					else{
						die "$_ may not come from GATK\n";
					}
				}
				die "$_ singleton validate failed $singleton_validate!\n" if $singleton_validate == 1;
			}
			elsif ($AC == 0){  ##all samples genotype 0/0
				foreach my $index (9..$#genotype){
					if($genotype[$index] =~ /^0\/0|^0\|0/){
						$ref_hom{$header[$index]}++;
					}
					elsif($genotype[$index] =~ /^\.\/./){
						$missing{$header[$index]}++;
					}
					else{
						die "$genotype[$index] may not come from GATK\n";
					}
				}
			}
			else{
				die "$_ may not come from GATK\n";
			}
		}
	}
}
close IN;
print STDERR "Parse Total Sites:$total_site\n";
open(OUT, ">$ARGV[1]") or die "permission denied\n";
print OUT "SAMPLE\tSNP\tHET\tFIX\tREF_HOM\tMISS\tSINGLE\n";
foreach my $sample_index (9..$#header){
	print OUT $header[$sample_index],"\t",$snp{$header[$sample_index]},"\t",$het{$header[$sample_index]},"\t",$fix{$header[$sample_index]},"\t",$ref_hom{$header[$sample_index]},"\t",$missing{$header[$sample_index]},"\t",$singleton{$header[$sample_index]},"\n";
}
close OUT;
