#!/usr/bin/perl
use strict;


# perform this program : perl $0 $s_win $aligned_per $full_align
## change this part to your parameters
my $ref = "FCA_chr.genome.fasta"; # change this into your own data
my $abbr = $ref; $abbr =~ s/_chr\.genome\.fasta$//;
my $sp_num = 10;
my $fir_match = "LCA";
my $outgroup = "LCA";
my @other_sp = ("OMA", "PPL", "PVI", "PRU", "PBE", "FCH", "FNI", "FMA");

my $s_win = $ARGV[0] ||= 50000;#my $win = "500000";# 50kb, 100kb, 200kb, 500kb(for close relatives)
my $aligned_per = $ARGV[1] ||= 0.25; ## 25%, 30%, 40%, 50%, 60%, 70%, 75% gaps with "N", gradually strict from 0.75 to 0.25
my $full_align = $ARGV[2] ||= 200; ## usually default 5000, you need change this parameters based on your own data

my $astral = "/DATADISK/yuanjq/biosoft_shared/phylogeny/ASTRAL-master/Astral/astral.5.7.3.jar";
##

my $main = `pwd`; chomp $main;
# step 0: predeal.ori.data
print "step 0: predeal.genome\n";
my $ori = "0.genome"; unless(-e "$ori"){system("mkdir -p $ori");}
unless(-e "0.predeal_genome.ok"){
	chdir $ori;
	my $ori_ge = "0.download_manually";
	
	print "step 0.1:hardmask\n";	
	my $hmask_dir = "1.hardmask"; unless(-e $hmask_dir){system("mkdir -p $hmask_dir");}
	unless(-e "1.hardmask.ok"){
		opendir(ORI_GDIR, "./$ori_ge") or die $!;#you need manually download genomes and name into the form: "FCA_***.fna";
		my $ori_genomes = grep(/\.fna$/,readdir(ORI_GDIR)); close ORI_GDIR;
		open(PA_HMASK, ">1.para_hardmask.txt") or die $!;
		foreach (sort $ori_genomes){
			my @names = split(/_/, $_); my $ab = $names[0];
			#system("perl $main/scripts/0.1.filter.chro_or_scaf.pl $_ $ab");
			print PA_HMASK "perl $main/scripts/0.filter.chro_or_scaf.pl $ori_ge $_ $ab $hmask_dir\n";
		}close PA_HMASK;
		system("ParaFly -c 1.para_hardmask.txt -CPU 32");
		open(OUT, ">1.hardmask.ok"); close OUT;
	}
	
	print "step 0.2:filter_scaf_len\n";	
	my $scaf_filL = "2.scaf_more_500"; unless(-e "$scaf_filL"){system("mkdir -p $scaf_filL");}
	unless(-e "2.filter_scaf_len.ok"){
		opendir(HDIR, "$hmask_dir") or die $!; my @hm_genomes = grep(/\.fasta/, readdir(HDIR)); close HDIR;
		open(PA_FSL, ">2.para_filter_sca_len.txt") or die $!;
		foreach (sort @hm_genomes){
			my $out = $_; $out =~ s/\.fasta$/.scaf_500.fasta/;
			#system("faFilter -minSize=500 $hmask_dir/$_ $scaf_filL/$out");
			print PA_FSL "faFilter -minSize=500 $hmask_dir/$_ $scaf_filL/$out\n";
		}close PA_FSL;
		system("ParaFly -c 2.para_filter_sca_len.txt -CPU 32");
		open(OUT, ">2.filter_scaf_len.ok"); close OUT;
	}

	print "step 0.3:filter_scaf_N90percent\n";		
	my $scaf_filN = "3.scaf_Nless90"; unless(-e "$scaf_filN"){system("mkdir -p $scaf_filN");}
	unless(-e "3.filter_scaf_N90per.ok"){
		opendir(SFL_DIR, "$scaf_filL") or die $!; my @scaf_filL_genomes = grep(/\.fasta/, readdir(SFL_DIR)); close SFL_DIR;
		open(PA_FSN, ">3.para_filter_sca_N90per.txt") or die $!;
		foreach (sort @scaf_filL_genomes){
			my $out = $_; $out =~ s/\.scaf_500\.fasta$/.fasta/; my$upcase = $out; $upcase =~ s/\.fasta$/.fas/; 
			#system("faFilterN $scaf_filL/$_ $scaf_filN/$out 90");
			print PA_FSN "faFilterN $scaf_filL/$_ $scaf_filN/$out 90 && perl $main/scripts/0.upcase.pl $scaf_filN/$out $scaf_filN/$upcase\n";
		}close PA_FSN;
		system("ParaFly -c 3.para_filter_sca_N90per.txt -CPU 32");
		open(OUT, ">3.filter_scaf_N90per.ok"); close OUT;
	}
	
	chdir $main;
	open(OUT, ">0.predeal_genome.ok"); close OUT;	
}

# step 1: alignment
print "step 1: multiple.genome.alignment\n";
my $align = "1.multi_alignment"; unless(-e "$align"){system("mkdir -p $align");}
unless(-e "1.alignment.ok"){
	chdir $align;
	
	print "step 1.0: predeal.alignment\n";
	my $pre_align = "1.0.ref_chrs"; unless(-e "$pre_align"){system("mkdir -p $pre_align");}
	unless(-e "1.0.split_ref_chrs.ok"){
		system("perl $main/scripts/1.0.split.ref.chr.pl $main/$ori/0.download_manually/ref_genome $ref $pre_align $abbr");
		open(OUT, ">1.0.split_ref_chrs.ok"); close OUT;		
	}
	
	
	print "step 1.1: lastdb_lastal\n";
	my $last_dir = "1.1.lastdb_lastal"; unless(-e "$last_dir"){system("mkdir -p $last_dir");}
	unless(-e "1.1.1.lastdb.ok"){
		system("perl $main/scripts/1.1.1.pararun.lastdb.pl $pre_align $last_dir");
		open(OUT, ">1.1.1.lastdb.ok"); close OUT;		
	}
	unless(-e "1.1.2.lastal.ok"){
		system("perl $main/scripts/1.1.2.pararun.lastal.pl $last_dir $abbr $main/$ori/3.scaf_Nless90 64");
		open(OUT, ">1.1.2.lastal.ok"); close OUT;		
	}
	unless(-e "1.1.3.sort.lastal.ok"){
		system("perl $main/scripts/1.1.3.pararun.sort.last.pl $last_dir $abbr 32");
		open(OUT, ">1.1.3.sort.lastal.ok"); close OUT;
	}
	
	print "step 1.2: multiz\n";
	my $multiz_dir = "1.2.multiz"; unless(-e "$multiz_dir"){system("mkdir -p $multiz_dir");}
	unless(-e "1.2.multiz.ok"){
		opendir(ST, $last_dir) or die "$!"; my @sorted_chrs = grep(/^$abbr/, readdir(ST)); close ST;
		chdir $multiz_dir;
		#chdir $last_dir;
		my $pa_multiz = "1.2.pararun.multiz.txt";
		open(PA_MZ, ">$pa_multiz") or die $!;
		foreach my $sort_chr (sort @sorted_chrs){
			print PA_MZ "perl $main/scripts/1.2.multiz.pl $last_dir $sort_chr $abbr $fir_match @other_sp\n";
		}close PA_MZ;
		system("ParaFly -c $pa_multiz -CPU 80");
		chdir "../";
		open(OUT, ">1.2.multiz.ok"); close OUT;
	}

	chdir $main;
	open(OUT, ">1.alignment.ok"); close OUT;
}

# step 2: split alignment into windows
print "step 2: split alignment into windows\n";
my $split_wins = "2.split_wins"; unless(-e "$split_wins"){system("mkdir -p $split_wins");}
unless(-e "2.split.win.ok"){
	chdir $split_wins;
	## step2.1: rename_standard
	unless(-e "2.0.rename.ok"){
		opendir(MUL, "../$align/1.2.multiz") or die $!; my @multiz_files = grep(/$fir_match\.$other_sp[0]\.$other_sp[1]\.$other_sp[2]\.$other_sp[3]\.$other_sp[4]\.$other_sp[5]\.$other_sp[6]\.$other_sp[7]\.sorted\.maf$/, readdir(MUL)); close MUL;
		foreach my $file (@multiz_files){
			print "$file\n";
			my $out_dir = "0.renamed.maf";unless(-e $out_dir){system("mkdir -p $out_dir");}
			my $out = $file; $out =~ s/\-.*$//; $out =~ s/^$abbr\_//; $out =~ s/^0+//; $out = "$sp_num.species.chr".$out.".maf";
			open(IN, "../$align/1.2.multiz/$file") or die "$!";
			open(OUT, ">$out_dir/$out") or die "$!";#renamed
			$/ = "a score";my $i = 0;
			while(<IN>){
				$i++;
				chomp($_);
				if($i == 1){print OUT "$_"; next;}
				my @arr = split(/\n/, $_);

				$arr[0] = "a score".$arr[0];
				$arr[1] =~ s/^s\s$abbr\_(\S+)/s $abbr.$1    /;
				$arr[2] =~ s/^s\s/s $fir_match./;
				$arr[3] =~ s/^s\s/s $other_sp[0]./;
				$arr[4] =~ s/^s\s/s $other_sp[1]./;
				$arr[5] =~ s/^s\s/s $other_sp[2]./;
				$arr[6] =~ s/^s\s/s $other_sp[3]./; # mannually change this para.
				$arr[7] =~ s/^s\s/s $other_sp[4]./; # mannually change this para.
				$arr[8] =~ s/^s\s/s $other_sp[5]./; # mannually change this para.
				$arr[9] =~ s/^s\s/s $other_sp[6]./; # mannually change this para.
				$arr[10] =~ s/^s\s/s $other_sp[7]./; # mannually change this para.
				for(my $j=0; $j<=$sp_num; $j++){print OUT "$arr[$j]\n";}
				print OUT "\n";
			}
			close IN;close OUT;
		}
		open(OUT, ">2.0.rename.ok"); close OUT;	
	}
	
	## step2.1: split_win_fill_gap
	unless(-e "2.1.split.ok"){
		my $indir1 = "./0.renamed.maf";
		opendir(RED, "./0.renamed.maf") or die "$!";my @renamed_files = grep(/maf$/, readdir(RED));close RED;
		my $outdir1 = "1.out_matrix"; my $sec_dir = "1.1.ori_matrix"; unless(-e "$outdir1/$sec_dir"){system("mkdir -p $outdir1/$sec_dir");}
		open(PA_SP, ">2.1.para_run.split.txt") or die $!;
		foreach my $maf (@renamed_files){
			#system("perl $main/scripts/2.1.split.own_make.pl $maf");
			print PA_SP "perl $main/scripts/2.1.split.own_make.pl $indir1 $maf $outdir1 $sec_dir $abbr $fir_match $other_sp[0] $other_sp[1] $other_sp[2] $other_sp[3] $other_sp[4] $other_sp[5] $other_sp[6] $other_sp[7]\n"; # manually change this sub script
		}close PA_SP;
		system("ParaFly -c 2.1.para_run.split.txt -CPU 80");
		open(OUT, ">2.1.split.ok"); close OUT;
	}
	chdir $main;
	open(OUT, ">2.split.win.ok"); close OUT;
}
	
	
# step 3: split alignment into fix windows to construct tree
print "step 3: split fix windows and construct tree\n";
my $split_to_tree = "3.split_construct_tree_".$s_win."_".$aligned_per; unless(-e "$split_to_tree"){system("mkdir -p $split_to_tree");}
unless(-e "3.split.to.tree.$s_win.$aligned_per.ok"){
	chdir $split_to_tree;	
	## step3.0: split_win_matrix
	print "step3.0: split_win_matrix\n";
	unless(-e "3.0.split.matrix.ok"){
		my $indir2 = "../2.split_wins/1.out_matrix/1.1.ori_matrix";
		opendir(IDIR2, "$indir2") or die "$!";my @folders2 = grep(/\.txt$/, readdir(IDIR2));close IDIR2;
		my $outdir2 = "0.split_matrix".$s_win; unless(-e $outdir2){system("mkdir -p $outdir2");}
		my $split_matrix_parafly = "3.0.para_run.split.matrix.txt";
		open SM_PF, ">".$split_matrix_parafly or die "$!"; 
		foreach my $infile (@folders2){
			#my $count = system("wc -l $indir/$infile | ls");
			my $count = `wc -l $indir2/$infile`;
			my @array = split(/\s+/, $count); my $f_lines = $array[0] - 1;
			print "$count\t$f_lines\n";
			print SM_PF "perl $main/scripts/3.0.split_win_matrix.pl $indir2 $s_win $outdir2 $infile $f_lines\n";
		}close SM_PF;
		system("ParaFly -c $split_matrix_parafly -CPU 20") == 0 or die "$!";
		open OUT, ">", "3.0.split.matrix.ok" or die $!; close OUT;	
	}

=pod	
	# step3.1: matrix_to_fasta # not use yet for the following pipe
	unless(-e "3.1.matrix_to_fasta.ok"){
		my $indir3 = "$main/3.1.split_matrix".$s_win;
		opendir(IDIR3, "$indir3") or die "$!";my @folders3 = grep(/matrix$/, readdir(IDIR3));close IDIR3;
		my $outdir3 = "3.1.out.matrix2fasta".$s_win; unless(-e $outdir3){system("mkdir -p $outdir3");}
		my $matrix_fasta_parafly = "3.1.parafly.matrix2fasta.txt";
		open MF_PF, ">".$matrix_fasta_parafly or die "$!"; 
		foreach my $folder (@folders3){
			print MF_PF "perl $main/scripts/3.1.matrix2fasta.bk.pl $s_win $indir3 $folder $outdir3 $abbr $fir_match $other_sp[0] $other_sp[1] $other_sp[2] $other_sp[2]\n";# mannually change the sub-script within "$main/scripts directory"
		}close MF_PF;
		system("ParaFly -c $matrix_fasta_parafly -CPU 20 &> /dev/null") == 0 or die "cannot execute \n";
		open OUT, ">", "3.1.matrix_to_fasta.ok" or die $!; close OUT;
	}
=cut	

	# step3.1: select high consensus fasta with conditions
	print "step3.1: select high consensus fasta with conditions\n";
	unless(-e "3.1.select.consensus.fasta.ok"){
		#my $full_align = 5000; ## usually 5000, you need change this parameters based on your own data
		my $indir4 = "./0.split_matrix".$s_win; opendir(IDIR4, "$indir4") or die "$!";my @folders4 = grep(/matrix$/, readdir(IDIR4));close IDIR4;
		my $outdir4 = "1.out.matrix2fasta".$s_win; unless(-e $outdir4){system("mkdir -p $outdir4");}
		my $filter_fasta_parafly = "3.1.parafly.filter_fasta.txt";
		open FF_PF, ">".$filter_fasta_parafly or die "$!"; 
		foreach my $folder (@folders4){
			print FF_PF "perl $main/scripts/3.1.matrix2fasta.pl $s_win $indir4 $full_align $aligned_per $folder $outdir4 $abbr $fir_match $other_sp[0] $other_sp[1] $other_sp[2] $other_sp[3] $other_sp[4] $other_sp[5] $other_sp[6] $other_sp[7]\n";# munally change this sub-script
		}close FF_PF;
		system("ParaFly -c $filter_fasta_parafly -CPU 80");
		open OUT, ">", "3.1.select.consensus.fasta.ok" or die $!; close OUT;
	}

	# step3.2: transform the fasta into .phy
	print "step3.2: transform the fasta into .phy\n";
	unless(-e "3.2.fa2phy.ok"){
		my $indir5 = "./1.out.matrix2fasta$s_win";
		my $outdir5 = "./2.out.matrix2fasta$s_win.phy"; unless(-e $outdir5){system("mkdir -p $outdir5");}
		system("perl $main/scripts/3.2.Reorder_Change_phy_format.pl $s_win $indir5 $outdir5 $abbr $fir_match $other_sp[0] $other_sp[1] $other_sp[2] $other_sp[3] $other_sp[4] $other_sp[5] $other_sp[6] $other_sp[7]") == 0 or die "$!";
		open OUT, ">", "3.2.fa2phy.ok" or die $!; close OUT;
	}
	
	# step3.3: construct tree with raxml or iqtree, etc
	print "step3.3: construct tree with raxml or iqtree, etc\n";
	unless(-e "3.3.construct.tree.ok"){
		my $indir6 = "2.out.matrix2fasta$s_win.phy"; opendir(TOPD, $indir6) or die "$!";my @chrs = grep(/^chr/, readdir(TOPD));close TOPD;	
		my $outdir6 = "./3.out.win_$s_win.tree"; unless(-e $outdir6){system("mkdir -p $outdir6");}
		my $parafly_txt = "3.3.win.$s_win.parafly.txt";
		open(OUT, ">./$parafly_txt") or die "$!";
		foreach my $chr (@chrs){
			#system("chmod -R 755 $indir6/chr*/*.phy"); # change the file "755"
			opendir(CHRS,"$indir6/$chr") or die "$!"; my @array = grep(/phy$/,readdir(CHRS)) or die "$!"; close CHRS;
			my $out_chr = $chr; $out_chr = $out_chr.".tree"; unless(-e $out_chr){system("mkdir -p $outdir6/$out_chr");}
			foreach my $filename ( @array ){
				my $output=$filename; $output=~s/phy$/nwk/;
				print OUT "raxmlHPC-MPI-AVX -T 2 -f a -N 1000 -m GTRCAT -x 12345 -p 12345 --silent -s $indir6/$chr/$filename -o $outgroup -w $main/$split_to_tree/$outdir6/$out_chr -n $output\n";## -w must be absolute path
			}
		}close OUT;
		system("ParaFly -c $parafly_txt -CPU 64") == 0 or die $!;
		open OUT, ">", "3.3.construct.tree.ok" or die $!; close OUT;
	}

	# step3.3_1: construct unroot tree with raxml or iqtree, etc
	print "step3.3_1: construct unroottree with raxml or iqtree, etc\n";
	unless(-e "3.3.construct.unroottree.ok"){
		my $indir6 = "2.out.matrix2fasta$s_win.phy"; opendir(TOPD, $indir6) or die "$!";my @chrs = grep(/^chr/, readdir(TOPD));close TOPD;	
		my $outdir6_1 = "./3.out.win_$s_win.unroottree"; unless(-e $outdir6_1){system("mkdir -p $outdir6_1");}
		my $parafly_txt = "3.3.win.$s_win.parafly.unroottree.txt";
		open(OUT, ">./$parafly_txt") or die "$!";
		foreach my $chr (@chrs){
			#system("chmod -R 755 $indir6/chr*/*.phy"); # change the file "755"
			opendir(CHRS,"$indir6/$chr") or die "$!"; my @array = grep(/phy$/,readdir(CHRS)) or die "$!"; close CHRS;
			my $out_chr = $chr; $out_chr = $out_chr.".tree"; unless(-e $out_chr){system("mkdir -p $outdir6_1/$out_chr");}
			foreach my $filename ( @array ){
				my $output=$filename; $output=~s/phy$/nwk/;
				print OUT "raxmlHPC-MPI-AVX -T 2 -f a -N 1000 -m GTRCAT -x 12345 -p 12345 --silent -s $indir6/$chr/$filename -w $main/$split_to_tree/$outdir6_1/$out_chr -n $output\n";## -w must be absolute path
			}
		}close OUT;
		system("ParaFly -c $parafly_txt -CPU 64") == 0 or die $!;
		open OUT, ">", "3.3.construct.unroottree.ok" or die $!; close OUT;
	}


	# step3.4: select1 tree
	print "step3.4: select1 tree\n";
	unless(-e "3.4.select.tree.ok"){
		my $indir7 = "./3.out.win_$s_win.tree";
		my $outdir7 = "4.out.win_$s_win.filter.tree"; unless(-e $outdir7){system("mkdir -p $outdir7");}
		system("perl $main/scripts/3.4.select.topology.tree.pl $s_win $indir7 $outdir7") == 0 or die "cannot execute \n";
		open OUT, ">", "3.4.select.tree.ok" or die $!; close OUT;
	}
	
	# step3.4_1: select1 tree
	print "step3.4_1: select1 unroottree\n";
	unless(-e "3.4.select.unroottree.ok"){
		my $indir7 = "./3.out.win_$s_win.unroottree";
		my $outdir7_1 = "4.out.win_$s_win.filter.unroottree"; unless(-e $outdir7_1){system("mkdir -p $outdir7_1");}
		system("perl $main/scripts/3.4.select.topology.tree.pl $s_win $indir7 $outdir7_1") == 0 or die "cannot execute \n";
		system("cat $outdir7_1/*.txt >./combined.all.unroottree.txt && java -jar $astral -r 1000 -i ./combined.all.unroottree.txt -o ./astral.nwk") == 0 or die "cannot execute \n";
		open OUT, ">", "3.4.select.unroottree.ok" or die $!; close OUT;
	}	

	# step3.4: select2 tree
	print "step3.4: select2 tree\n";
	unless(-e "3.4.select.up.tree.ok"){
		my $indir8 = "4.out.win_$s_win.filter.tree";
		my $outdir8 = "4.up1.out.win_$s_win.filter.tree"; unless(-e $outdir8){system("mkdir -p $outdir8");}		
		system("perl $main/scripts/3.4.up1.select.topology.tree.pl $s_win $indir8 $outdir8") == 0 or die "cannot execute \n";
		open OUT, ">", "3.4.select.up.tree.ok" or die $!; close OUT;
	}
	
	# step3.5: cal tree
	print "step3.5: calculate tree\n";
	unless(-e "3.5.calculate.tree.ok"){
		my $indir9 = "4.up1.out.win_$s_win.filter.tree"; my $indir10 = "3.out.win_$s_win.tree";
		my $outdir10 = "combined.out"; unless(-e $outdir10){system("mkdir -p $outdir10");}		
		system("perl $main/scripts/3.5.combine.pl $main/configures/felidea.karyotype.txt $indir9 $outdir10 $s_win $aligned_per") == 0 or die "cannot execute \n";
		open OUT, ">", "3.5.calculate.tree.ok" or die $!; close OUT;
	}
	
	chdir $main;
	open(OUT, ">3.split.to.tree.$s_win.$aligned_per.ok"); close OUT;
}

print "*all_pipe.done*\n";
